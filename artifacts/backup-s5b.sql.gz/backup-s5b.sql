-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: req_6343a752e110
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `address` varchar(200) NOT NULL,
  `usage_count` int NOT NULL DEFAULT '0',
  `last_used_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_addr_user_address` (`user_id`,`address`),
  KEY `idx_addr_user_last` (`user_id`,`last_used_at`),
  CONSTRAINT `fk_addr_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,2,'Building A, 12F, WeBox HQ',1,'2026-11-14 22:20:25.414','2026-11-14 22:17:47.208'),(2,2,'Building A, 12F',2,'2026-11-14 22:20:43.728','2026-11-14 22:18:55.035'),(5,1,'Building A, 12F (FE integration)',0,NULL,'2026-11-14 22:23:36.308'),(6,2,'Timeout Test Address',0,NULL,'2026-11-14 22:24:47.946'),(7,1,'Building A, 12F',1,'2026-11-14 22:44:49.087','2026-11-14 22:25:42.614'),(8,2,'Redis Compensation Test',0,NULL,'2026-11-14 22:28:15.603'),(9,2,'Admin Flow Test',0,NULL,'2026-11-14 22:37:35.108'),(10,110,'Building A, 12F',0,NULL,'2026-11-14 22:41:28.153'),(11,112,'Building A',0,NULL,'2026-11-14 22:41:48.847'),(13,2,'Office 1F, Test Street',0,NULL,'2026-11-14 22:46:33.021');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_conversation`
--

DROP TABLE IF EXISTS `ai_conversation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_conversation` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `session_id` varchar(64) DEFAULT NULL,
  `prompt` varchar(500) NOT NULL,
  `response_json` json DEFAULT NULL,
  `dish_ids` json DEFAULT NULL,
  `model` varchar(64) DEFAULT NULL,
  `fallback` tinyint(1) NOT NULL DEFAULT '0',
  `latency_ms` int DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_ai_conv_user` (`user_id`,`created_at`),
  CONSTRAINT `fk_ai_conv_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_conversation`
--

LOCK TABLES `ai_conversation` WRITE;
/*!40000 ALTER TABLE `ai_conversation` DISABLE KEYS */;
INSERT INTO `ai_conversation` VALUES (1,2,'s-ed53feac','light and high protein lunch','{\"dishIds\": [11, 2, 15, 6, 14]}','[11, 2, 15, 6, 14]','rule-based',1,13,'2026-11-14 22:18:19.231'),(2,2,'s-eab12ae6','light and high protein lunch','{\"dishIds\": [11, 2, 15, 6, 14]}','[11, 2, 15, 6, 14]','rule-based',1,12,'2026-11-14 22:18:55.623'),(3,2,'s-2529914e','light and high protein lunch','{\"dishIds\": [11, 2, 15, 6, 14]}','[11, 2, 15, 6, 14]','rule-based',1,9,'2026-11-14 22:20:06.579'),(4,2,'s-8af28127','light and high protein lunch','{\"dishIds\": [11, 2, 15, 6, 14]}','[11, 2, 15, 6, 14]','rule-based',1,12,'2026-11-14 22:20:44.358'),(5,1,'a700861e-f61d-4172-b204-3d1bfad750bd','Something light with chicken','{\"dishIds\": [2, 15, 6, 14, 9]}','[2, 15, 6, 14, 9]','rule-based',1,10,'2026-11-14 22:26:04.141'),(6,1,'fa62bc3b-f5ed-4289-b2e2-12f31d189311','Something light and high protein','{\"dishIds\": [11, 2, 15, 6, 14]}','[11, 2, 15, 6, 14]','rule-based',1,9,'2026-11-14 22:46:01.054');
/*!40000 ALTER TABLE `ai_conversation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_rule_config`
--

DROP TABLE IF EXISTS `ai_rule_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_rule_config` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `config_key` varchar(64) NOT NULL,
  `version` int NOT NULL,
  `config_json` json NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `change_reason` varchar(200) DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ai_rule_version` (`config_key`,`version`),
  KEY `idx_ai_rule_active` (`config_key`,`active`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_rule_config`
--

LOCK TABLES `ai_rule_config` WRITE;
/*!40000 ALTER TABLE `ai_rule_config` DISABLE KEYS */;
INSERT INTO `ai_rule_config` VALUES (1,'recommend_weights',1,'{\"taste\": 1, \"protein\": 1, \"budgetFit\": 2, \"spiceMatch\": 2, \"preferredCategory\": 3}',0,'initial rule weights',1,'2026-11-14 22:17:47.282'),(4,'recommend_weights',2,'{\"taste\": 1, \"protein\": 1, \"budgetFit\": 2, \"spiceMatch\": 2, \"preferredCategory\": 3}',0,'s5b ai rule',1,'2026-11-14 22:52:00.847'),(5,'recommend_weights',3,'{\"preferredCategory\": 3}',1,'s5b ai rule 2',1,'2026-11-14 22:52:00.881');
/*!40000 ALTER TABLE `ai_rule_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `actor_id` bigint unsigned DEFAULT NULL,
  `actor_email` varchar(200) DEFAULT NULL,
  `action` varchar(64) NOT NULL,
  `object_type` varchar(32) NOT NULL,
  `object_id` varchar(64) DEFAULT NULL,
  `before_json` json DEFAULT NULL,
  `after_json` json DEFAULT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `request_id` varchar(64) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_audit_object` (`object_type`,`object_id`),
  KEY `idx_audit_actor` (`actor_id`,`created_at`),
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES (6,1,'admin@webox.com','STOCK_UPDATE','STOCK','9:2026-11-15',NULL,'{\"totalQty\": 0, \"available\": 0}','smoke test sold out','127.0.0.1','b753b003-e707-4e10-84b3-8899d9c56366','2026-11-14 22:20:44.030'),(7,1,'admin@webox.com','STOCK_UPDATE','STOCK','9:2026-11-15',NULL,'{\"totalQty\": 30, \"available\": 30}','restore after smoke test','127.0.0.1','553ca606-ec60-4d07-bf59-0e6451d15bd6','2026-11-14 22:20:44.072'),(8,1,'admin@webox.com','ORDER_CANCEL','ORDER','4','{\"status\": \"Pending\"}','{\"status\": \"Cancelled\"}','FE integration test','127.0.0.1','c5535fac-5f95-414d-b3e6-773714379c33','2026-11-14 22:23:36.577'),(9,1,'admin@webox.com','ORDER_CANCEL','ORDER','6','{\"status\": \"Pending\"}','{\"status\": \"Cancelled\"}','Frontend UI integration test cleanup','127.0.0.1','00e363b2-7b5a-4efa-a3e8-88162dc2b907','2026-11-14 22:28:25.282'),(10,1,'admin@webox.com','ORDER_STATUS','ORDER','8','{\"status\": \"Pending\"}','{\"status\": \"Confirmed\"}','kitchen accepted','127.0.0.1','082005ed-6814-41bd-a263-7f90bfc7107b','2026-11-14 22:37:35.173'),(11,1,'admin@webox.com','ORDER_STATUS','ORDER','8','{\"status\": \"Confirmed\"}','{\"status\": \"Completed\"}','delivered','127.0.0.1','77c29486-6c8b-4868-b9a9-18197729219e','2026-11-14 22:37:35.218'),(12,1,'admin@webox.com','STOCK_UPDATE','STOCK','17:2026-11-14','{\"sold_qty\": 0, \"total_qty\": 40, \"reserved_qty\": 0}','{\"totalQty\": 40, \"available\": 40}','review confirm-bypass probe (value unchanged)','127.0.0.1','916adc2b-149b-4c4c-a6ad-d8a7b706f92b','2026-11-14 22:41:17.224'),(13,1,'admin@webox.com','ORDER_STATUS','ORDER','10','{\"status\": \"Pending\"}','{\"status\": \"Confirmed\"}','kitchen accepted','127.0.0.1','3332ed39-4db1-415d-8609-66425987533c','2026-11-14 22:41:48.926'),(14,1,'admin@webox.com','DISH_UPDATE','DISH','9','{\"id\": 9, \"name\": \"Classic Beef Burger\", \"status\": \"ON_SHELF\", \"protein\": \"Beef\", \"category\": \"Western\", \"allergens\": \"[\\\"Gluten\\\", \\\"Dairy\\\"]\", \"image_url\": \"/images/image_09.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Angus beef patty with lettuce, tomato, onion\", \"price_cents\": 3800, \"spice_level\": \"None\"}','{\"id\": 9, \"name\": \"Classic Beef Burger\", \"status\": \"ON_SHELF\", \"protein\": \"Beef\", \"category\": \"Western\", \"allergens\": \"[\\\"Gluten\\\", \\\"Dairy\\\"]\", \"image_url\": \"/images/image_09.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Angus beef patty with lettuce, tomato, onion\", \"price_cents\": 3800, \"spice_level\": \"None\"}','AC-004 regression smoke (no-op update)','127.0.0.1','8f0d9b8a-8768-4096-a201-4f06abc71171','2026-11-14 22:43:40.217'),(15,1,'admin@webox.com','DISH_STATUS','DISH','9','{\"id\": 9, \"name\": \"Classic Beef Burger\", \"status\": \"ON_SHELF\", \"protein\": \"Beef\", \"category\": \"Western\", \"allergens\": \"[\\\"Gluten\\\", \\\"Dairy\\\"]\", \"image_url\": \"/images/image_09.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Angus beef patty with lettuce, tomato, onion\", \"price_cents\": 3800, \"spice_level\": \"None\"}','{\"id\": 9, \"name\": \"Classic Beef Burger\", \"status\": \"ON_SHELF\", \"protein\": \"Beef\", \"category\": \"Western\", \"allergens\": \"[\\\"Gluten\\\", \\\"Dairy\\\"]\", \"image_url\": \"/images/image_09.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Angus beef patty with lettuce, tomato, onion\", \"price_cents\": 3800, \"spice_level\": \"None\"}','AC-004 regression smoke (no-op status)','127.0.0.1','872857d9-3458-4f20-b510-86fb9be09916','2026-11-14 22:43:40.237'),(16,1,'admin@webox.com','DISH_STATUS','DISH','20','{\"id\": 20, \"name\": \"Vegan Buddha Bowl\", \"status\": \"ON_SHELF\", \"protein\": \"Tofu\", \"category\": \"Light Meal\", \"allergens\": \"[\\\"Soy\\\"]\", \"image_url\": \"/images/image_20.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Roasted vegetables, tofu and grains with tahini dressing\", \"price_cents\": 2600, \"spice_level\": \"None\"}','{\"id\": 20, \"name\": \"Vegan Buddha Bowl\", \"status\": \"ON_SHELF\", \"protein\": \"Tofu\", \"category\": \"Light Meal\", \"allergens\": \"[\\\"Soy\\\"]\", \"image_url\": \"/images/image_20.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Roasted vegetables, tofu and grains with tahini dressing\", \"price_cents\": 2600, \"spice_level\": \"None\"}','BR verify audit datetime','127.0.0.1','690e3f44-0f3e-4d91-bbb2-364c5cf11493','2026-11-14 22:45:50.697'),(17,1,'admin@webox.com','STOCK_UPDATE','STOCK','17:2026-11-14','{\"sold_qty\": 0, \"total_qty\": 40, \"reserved_qty\": 0}','{\"totalQty\": 40, \"available\": 40}','BR confirm=false probe','127.0.0.1','099f2ecb-7196-4667-9a26-6cdb08cd0f0a','2026-11-14 22:45:50.734'),(18,1,'admin@webox.com','DISH_UPDATE','DISH','20','{\"id\": 20, \"name\": \"Vegan Buddha Bowl\", \"status\": \"ON_SHELF\", \"protein\": \"Tofu\", \"category\": \"Light Meal\", \"allergens\": \"[\\\"Soy\\\"]\", \"image_url\": \"/images/image_20.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Roasted vegetables, tofu and grains with tahini dressing\", \"price_cents\": 2600, \"spice_level\": \"None\"}','{\"id\": 20, \"name\": \"Vegan Buddha Bowl\", \"status\": \"ON_SHELF\", \"protein\": \"Tofu\", \"category\": \"Light Meal\", \"allergens\": \"[\\\"Soy\\\"]\", \"image_url\": \"/images/image_20.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Roasted vegetables, tofu and grains with tahini dressing\", \"price_cents\": 2600, \"spice_level\": \"None\"}','arch audit fixed-jar probe','127.0.0.1','66bd1ad1-c62b-4c6d-ae81-295ba177c2b7','2026-11-14 22:46:46.669'),(19,1,'admin@webox.com','DISH_UPDATE','DISH','20','{\"id\": 20, \"name\": \"Vegan Buddha Bowl\", \"status\": \"ON_SHELF\", \"protein\": \"Tofu\", \"category\": \"Light Meal\", \"allergens\": \"[\\\"Soy\\\"]\", \"image_url\": \"/images/image_20.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Roasted vegetables, tofu and grains with tahini dressing\", \"price_cents\": 2600, \"spice_level\": \"None\"}','{\"id\": 20, \"name\": \"Vegan Buddha Bowl\", \"status\": \"ON_SHELF\", \"protein\": \"Tofu\", \"category\": \"Light Meal\", \"allergens\": \"[\\\"Soy\\\"]\", \"image_url\": \"/images/image_20.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Roasted vegetables, tofu and grains with tahini dressing\", \"price_cents\": 2600, \"spice_level\": \"None\"}','arch audit confirm-false probe fixed-jar','127.0.0.1','b70a22a7-145e-484d-bdef-63b2fc06787a','2026-11-14 22:46:46.716'),(20,1,'admin@webox.com','DISH_UPDATE','DISH','20','{\"id\": 20, \"name\": \"Vegan Buddha Bowl\", \"status\": \"ON_SHELF\", \"protein\": \"Tofu\", \"category\": \"Light Meal\", \"allergens\": \"[\\\"Soy\\\"]\", \"image_url\": \"/images/image_20.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:17:47.181\", \"description\": \"Roasted vegetables, tofu and grains with tahini dressing\", \"price_cents\": 2600, \"spice_level\": \"None\"}','{\"id\": 20, \"name\": \"Kung Pao Chicken\", \"status\": \"ON_SHELF\", \"protein\": \"Chicken\", \"category\": \"Chinese\", \"allergens\": \"[\\\"Peanuts\\\"]\", \"image_url\": \"/images/image_03.jpg\", \"created_at\": \"2026-11-14T22:17:47.181\", \"updated_at\": \"2026-11-14T22:51:24.251\", \"description\": \"Spicy chicken with peanuts\", \"price_cents\": 1880, \"spice_level\": \"Hot\"}','s5b deploy verify','127.0.0.1','3fcb89a3-788e-4d78-b913-2e280f68a12b','2026-11-14 22:51:24.262'),(22,1,'admin@webox.com','STOCK_UPDATE','STOCK','20:2026-11-16','{\"sold_qty\": 0, \"total_qty\": 40, \"reserved_qty\": 0}','{\"totalQty\": 50, \"available\": 50}','s5b stock sse','127.0.0.1','27a9dbe5-27a3-4b53-97f0-44d49ca37dcd','2026-11-14 22:51:24.729'),(23,1,'admin@webox.com','AI_RULE_UPDATE','AI_RULE','recommend_weights:v2',NULL,'{\"version\": 2, \"rollbackToVersion\": null}','s5b ai rule','127.0.0.1','b3b04e95-65d1-4d4d-a04d-339c978ef6c4','2026-11-14 22:52:00.854'),(24,1,'admin@webox.com','AI_RULE_UPDATE','AI_RULE','recommend_weights:v3',NULL,'{\"version\": 3, \"rollbackToVersion\": null}','s5b ai rule 2','127.0.0.1','73b1e270-12f2-4a22-b781-be28f2e80666','2026-11-14 22:52:00.882');
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_menu`
--

DROP TABLE IF EXISTS `daily_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_menu` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `dish_id` bigint unsigned NOT NULL,
  `serve_date` date NOT NULL,
  `publish_status` enum('DRAFT','PUBLISHED') NOT NULL DEFAULT 'PUBLISHED',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_menu_dish_date` (`dish_id`,`serve_date`),
  KEY `idx_menu_date_status` (`serve_date`,`publish_status`),
  CONSTRAINT `fk_menu_dish` FOREIGN KEY (`dish_id`) REFERENCES `dishes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_menu`
--

LOCK TABLES `daily_menu` WRITE;
/*!40000 ALTER TABLE `daily_menu` DISABLE KEYS */;
INSERT INTO `daily_menu` VALUES (1,1,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(2,7,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(3,10,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(4,11,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(5,4,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(6,9,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(7,12,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(8,13,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(9,17,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(10,3,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(11,14,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(12,15,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(13,2,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(14,6,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(15,16,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(16,20,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(17,8,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(18,18,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(19,5,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(20,19,'2026-11-14','PUBLISHED',1,'2026-11-14 22:17:47.213','2026-11-14 22:17:47.213'),(32,1,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(33,7,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(34,10,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(35,11,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(36,4,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(37,9,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(38,12,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(39,13,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(40,17,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(41,3,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(42,14,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(43,15,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(44,2,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(45,6,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(46,16,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(47,20,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(48,8,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(49,18,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(50,5,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(51,19,'2026-11-15','PUBLISHED',1,'2026-11-14 22:17:47.221','2026-11-14 22:17:47.221'),(63,1,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(64,7,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(65,10,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(66,11,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(67,4,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(68,9,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(69,12,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(70,13,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(71,17,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(72,3,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(73,14,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(74,15,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(75,2,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(76,6,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(77,16,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(78,20,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(79,8,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(80,18,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(81,5,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230'),(82,19,'2026-11-16','PUBLISHED',1,'2026-11-14 22:17:47.230','2026-11-14 22:17:47.230');
/*!40000 ALTER TABLE `daily_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dish_daily_stock`
--

DROP TABLE IF EXISTS `dish_daily_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dish_daily_stock` (
  `dish_id` bigint unsigned NOT NULL,
  `serve_date` date NOT NULL,
  `total_qty` int NOT NULL DEFAULT '0',
  `reserved_qty` int NOT NULL DEFAULT '0',
  `sold_qty` int NOT NULL DEFAULT '0',
  `inventory_mode` enum('DB_ATOMIC','REDIS_PREALLOC') NOT NULL DEFAULT 'DB_ATOMIC',
  `version` bigint NOT NULL DEFAULT '0',
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`dish_id`,`serve_date`),
  KEY `idx_stock_date` (`serve_date`),
  CONSTRAINT `fk_stock_dish` FOREIGN KEY (`dish_id`) REFERENCES `dishes` (`id`),
  CONSTRAINT `ck_stock_nonneg` CHECK (((`total_qty` >= 0) and (`reserved_qty` >= 0) and (`sold_qty` >= 0) and ((`reserved_qty` + `sold_qty`) <= `total_qty`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dish_daily_stock`
--

LOCK TABLES `dish_daily_stock` WRITE;
/*!40000 ALTER TABLE `dish_daily_stock` DISABLE KEYS */;
INSERT INTO `dish_daily_stock` VALUES (1,'2026-11-14',40,0,0,'REDIS_PREALLOC',0,'2026-11-14 22:17:47.217'),(1,'2026-11-15',40,5,0,'DB_ATOMIC',1,'2026-11-14 22:44:49.085'),(1,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(2,'2026-11-14',30,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(2,'2026-11-15',40,0,2,'DB_ATOMIC',2,'2026-11-14 22:41:48.924'),(2,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(3,'2026-11-14',25,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(3,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(3,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(4,'2026-11-14',35,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(4,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(4,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(5,'2026-11-14',20,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(5,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(5,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(6,'2026-11-14',30,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(6,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(6,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(7,'2026-11-14',45,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(7,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(7,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(8,'2026-11-14',28,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(8,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(8,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(9,'2026-11-14',30,0,0,'REDIS_PREALLOC',4,'2026-11-14 22:18:55.362'),(9,'2026-11-15',30,0,0,'DB_ATOMIC',12,'2026-11-14 22:41:28.584'),(9,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(10,'2026-11-14',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(10,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(10,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(11,'2026-11-14',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(11,'2026-11-15',40,5,3,'DB_ATOMIC',9,'2026-11-14 22:46:33.019'),(11,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(12,'2026-11-14',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(12,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(12,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(13,'2026-11-14',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(13,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(13,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(14,'2026-11-14',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(14,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(14,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(15,'2026-11-14',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(15,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(15,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(16,'2026-11-14',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(16,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(16,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(17,'2026-11-14',40,0,0,'DB_ATOMIC',2,'2026-11-14 22:45:50.731'),(17,'2026-11-15',40,0,1,'DB_ATOMIC',4,'2026-11-14 22:37:35.172'),(17,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(18,'2026-11-14',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(18,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(18,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(19,'2026-11-14',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(19,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.225'),(19,'2026-11-16',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.233'),(20,'2026-11-14',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:17:47.217'),(20,'2026-11-15',40,0,0,'DB_ATOMIC',0,'2026-11-14 22:28:05.407'),(20,'2026-11-16',50,0,0,'DB_ATOMIC',1,'2026-11-14 22:51:24.726');
/*!40000 ALTER TABLE `dish_daily_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dish_option_groups`
--

DROP TABLE IF EXISTS `dish_option_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dish_option_groups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `dish_id` bigint unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `min_select` int NOT NULL DEFAULT '0',
  `max_select` int NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_groups_dish` (`dish_id`,`sort_order`),
  CONSTRAINT `fk_groups_dish` FOREIGN KEY (`dish_id`) REFERENCES `dishes` (`id`),
  CONSTRAINT `ck_groups_select` CHECK (((`min_select` >= 0) and (`max_select` >= `min_select`)))
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dish_option_groups`
--

LOCK TABLES `dish_option_groups` WRITE;
/*!40000 ALTER TABLE `dish_option_groups` DISABLE KEYS */;
INSERT INTO `dish_option_groups` VALUES (1,2,'Add-ons',0,0,3,1),(2,4,'Pasta Type',1,1,1,1),(3,4,'Add-ons',0,0,2,2),(4,6,'Base',1,1,1,1),(5,8,'Add-ons',0,0,3,1),(6,9,'Bun',1,1,1,1),(7,9,'Sauce',1,1,1,2),(8,9,'Add-ons',0,0,3,3),(9,12,'Add-ons',0,0,2,1),(10,13,'Sauce',1,1,1,1),(11,13,'Add-ons',0,0,2,2),(12,14,'Base',1,1,1,1),(13,16,'Add-ons',0,0,3,1),(14,17,'Add-ons',0,0,2,1),(15,19,'Add-ons',0,0,3,1),(16,20,'Base',1,1,1,1);
/*!40000 ALTER TABLE `dish_option_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dish_options`
--

DROP TABLE IF EXISTS `dish_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dish_options` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `group_id` bigint unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `price_delta_cents` bigint NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_options_group` (`group_id`,`sort_order`),
  CONSTRAINT `fk_options_group` FOREIGN KEY (`group_id`) REFERENCES `dish_option_groups` (`id`),
  CONSTRAINT `ck_options_delta` CHECK ((`price_delta_cents` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dish_options`
--

LOCK TABLES `dish_options` WRITE;
/*!40000 ALTER TABLE `dish_options` DISABLE KEYS */;
INSERT INTO `dish_options` VALUES (1,1,'Grilled Chicken',600,1),(2,1,'Bacon',500,2),(3,1,'Avocado',400,3),(4,2,'Spaghetti',0,1),(5,2,'Fusilli',0,2),(6,2,'Penne',0,3),(7,3,'Bacon',500,1),(8,3,'Cheese',300,2),(9,4,'Quinoa',0,1),(10,4,'Brown Rice',0,2),(11,4,'Mixed Grains',0,3),(12,5,'Cheese',300,1),(13,5,'Fried Egg',200,2),(14,5,'Beef Slices',800,3),(15,6,'Plain',0,1),(16,6,'Whole Wheat',0,2),(17,7,'Ketchup',0,1),(18,7,'Mustard',0,2),(19,7,'Mayo',0,3),(20,7,'BBQ',0,4),(21,8,'Cheese',300,1),(22,8,'Bacon',500,2),(23,8,'Fried Egg',200,3),(24,9,'Extra Cheese',300,1),(25,9,'Bacon',500,2),(26,10,'Ketchup',0,1),(27,10,'Mustard',0,2),(28,10,'Mayo',0,3),(29,10,'BBQ',0,4),(30,11,'Cheese',300,1),(31,11,'Bacon',500,2),(32,12,'White Rice',0,1),(33,12,'Brown Rice',0,2),(34,13,'Grilled Chicken',600,1),(35,13,'Avocado',400,2),(36,14,'Parmesan',300,1),(37,15,'Extra Shrimp',800,1),(38,15,'Peanuts',200,2),(39,16,'Quinoa',0,1),(40,16,'Brown Rice',0,2),(41,16,'Mixed Grains',0,3);
/*!40000 ALTER TABLE `dish_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dishes`
--

DROP TABLE IF EXISTS `dishes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dishes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `price_cents` bigint NOT NULL,
  `category` enum('Chinese','Western','Japanese','Light Meal','Korean','Southeast Asian') NOT NULL,
  `protein` varchar(50) NOT NULL,
  `allergens` json DEFAULT NULL,
  `spice_level` enum('None','Mild','Medium','Hot') NOT NULL DEFAULT 'None',
  `image_url` varchar(300) DEFAULT NULL,
  `status` enum('ON_SHELF','OFF_SHELF') NOT NULL DEFAULT 'ON_SHELF',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_dishes_status_category` (`status`,`category`),
  KEY `idx_dishes_name` (`name`),
  CONSTRAINT `ck_dishes_price` CHECK ((`price_cents` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dishes`
--

LOCK TABLES `dishes` WRITE;
/*!40000 ALTER TABLE `dishes` DISABLE KEYS */;
INSERT INTO `dishes` VALUES (1,'Kung Pao Chicken','Classic Sichuan dish, chicken stir-fried with peanuts and dried chili',2200,'Chinese','Chicken','[\"Peanuts\"]','Medium','/images/image_01.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(2,'Caesar Salad','Fresh romaine lettuce with Parmesan and Caesar dressing',2850,'Light Meal','None','[\"Dairy\", \"Egg\"]','None','/images/image_02.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(3,'Salmon Sashimi Set','Fresh salmon sashimi with rice and miso soup',4500,'Japanese','Fish','[\"Fish\"]','None','/images/image_03.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(4,'Tomato Pasta','Classic Italian tomato pasta with fresh basil',2650,'Western','None','[\"Gluten\"]','None','/images/image_04.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(5,'Tom Yum Soup','Thai hot & sour shrimp soup with lemongrass, galangal, lime leaves',3200,'Southeast Asian','Shrimp','[\"Shellfish\"]','Hot','/images/image_05.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(6,'Chicken Quinoa Bowl','Low-fat high-protein grilled chicken with quinoa, avocado, veggies',3580,'Light Meal','Chicken','[]','None','/images/image_06.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(7,'Mapo Tofu','Sichuan classic, soft tofu with spicy minced meat',1800,'Chinese','Tofu, Pork','[\"Soy\"]','Medium','/images/image_07.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(8,'Korean Bibimbap','Stone-pot mixed rice with veggies, fried egg, and chili sauce',3000,'Korean','Egg','[\"Egg\", \"Soy\"]','Mild','/images/image_08.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(9,'Classic Beef Burger','Angus beef patty with lettuce, tomato, onion',3800,'Western','Beef','[\"Gluten\", \"Dairy\"]','None','/images/image_09.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(10,'Sweet and Sour Pork','Crispy pork with bell peppers in sweet and sour sauce',2400,'Chinese','Pork','[\"Gluten\", \"Soy\"]','None','/images/image_10.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(11,'Beef Noodle Soup','Slow-cooked beef brisket with wheat noodles in rich broth',2800,'Chinese','Beef','[\"Gluten\", \"Soy\"]','Mild','/images/image_11.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(12,'Margherita Pizza','Wood-fired pizza with tomato, mozzarella and basil',3200,'Western','Dairy','[\"Gluten\", \"Dairy\"]','None','/images/image_12.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(13,'Grilled Chicken Sandwich','Grilled chicken breast with lettuce and tomato in a toasted bun',2900,'Western','Chicken','[\"Gluten\", \"Dairy\"]','None','/images/image_13.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(14,'Chicken Teriyaki Bento','Teriyaki chicken with rice, pickles and seasonal vegetables',3600,'Japanese','Chicken','[\"Soy\", \"Gluten\"]','Mild','/images/image_14.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(15,'California Roll','Crab, avocado and cucumber roll with sesame',2450,'Japanese','Crab','[\"Shellfish\", \"Egg\"]','None','/images/image_15.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(16,'Green Goddess Salad','Mixed greens with avocado and herb yogurt dressing',2500,'Light Meal','None','[\"Dairy\"]','None','/images/image_16.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(17,'Mushroom Risotto','Creamy Arborio rice with wild mushrooms and Parmesan',3000,'Western','Dairy','[\"Dairy\"]','None','/images/image_17.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(18,'Korean Fried Chicken','Double-fried chicken with spicy gochujang glaze',3300,'Korean','Chicken','[\"Gluten\", \"Soy\"]','Hot','/images/image_18.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(19,'Pad Thai','Stir-fried rice noodles with shrimp, egg and peanuts',2700,'Southeast Asian','Shrimp','[\"Peanuts\", \"Shellfish\", \"Egg\"]','Mild','/images/image_19.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:17:47.181'),(20,'Kung Pao Chicken','Spicy chicken with peanuts',1880,'Chinese','Chicken','[\"Peanuts\"]','Hot','/images/image_03.jpg','ON_SHELF','2026-11-14 22:17:47.181','2026-11-14 22:51:24.251');
/*!40000 ALTER TABLE `dishes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `idempotency_records`
--

DROP TABLE IF EXISTS `idempotency_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `idempotency_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `idem_key` varchar(64) NOT NULL,
  `request_hash` char(64) NOT NULL,
  `status` enum('IN_PROGRESS','COMPLETED','FAILED') NOT NULL DEFAULT 'IN_PROGRESS',
  `response_status` int DEFAULT NULL,
  `response_body` json DEFAULT NULL,
  `order_id` bigint unsigned DEFAULT NULL,
  `expires_at` datetime(3) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_idem_user_key` (`user_id`,`idem_key`),
  KEY `idx_idem_expires` (`expires_at`),
  KEY `fk_idem_order` (`order_id`),
  CONSTRAINT `fk_idem_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `fk_idem_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `idempotency_records`
--

LOCK TABLES `idempotency_records` WRITE;
/*!40000 ALTER TABLE `idempotency_records` DISABLE KEYS */;
INSERT INTO `idempotency_records` VALUES (16,2,'smoke-key-1794666043-01','1bdb0ba52c2ec75afd600f0d678a8f6c892d0267c10acb5b9faa5e1a5c91e046','COMPLETED',201,'{\"code\": \"OK\", \"data\": {\"status\": \"Pending\", \"address\": \"Building A, 12F\", \"orderId\": 3, \"orderNo\": \"WB20261115-0003\", \"mealType\": \"Lunch\", \"itemCount\": 1, \"totalCents\": 3800, \"autoSwitched\": true, \"deliveryDate\": \"2026-11-15\", \"estimatedDelivery\": \"Lunch on 2026-11-15\"}, \"message\": \"Order placed\"}',3,'2026-11-15 22:20:43.660','2026-11-14 22:20:43.660','2026-11-14 22:20:43.736'),(19,2,'smoke-key-1794666043-01-dup','1bdb0ba52c2ec75afd600f0d678a8f6c892d0267c10acb5b9faa5e1a5c91e046','COMPLETED',409,'{\"code\": \"ORDER_DUPLICATE\", \"data\": {\"existingOrderId\": 3, \"existingOrderNo\": \"WB20261115-0003\"}, \"message\": \"An active order already exists for this meal\"}',NULL,'2026-11-15 22:20:43.826','2026-11-14 22:20:43.826','2026-11-14 22:20:43.837'),(20,2,'smoke-key-1794666043-01-oos','1bdb0ba52c2ec75afd600f0d678a8f6c892d0267c10acb5b9faa5e1a5c91e046','COMPLETED',409,'{\"code\": \"STOCK_INSUFFICIENT\", \"data\": {\"details\": [{\"dishId\": 9, \"available\": 0, \"requested\": 1}]}, \"message\": \"Some dishes are sold out or insufficient\"}',NULL,'2026-11-15 22:20:44.046','2026-11-14 22:20:44.046','2026-11-14 22:20:44.057'),(21,1,'8cb15ade-d8b5-4d97-8d25-cd8c159632af','c93bf9b2064b0bdf5e15f5769ad20d40dc2aaafdc1bc613abc6a59ea50863a01','COMPLETED',201,'{\"code\": \"OK\", \"data\": {\"status\": \"Pending\", \"address\": \"Building A, 12F (FE integration)\", \"orderId\": 4, \"orderNo\": \"WB20261115-0004\", \"mealType\": \"Lunch\", \"itemCount\": 2, \"totalCents\": 5600, \"autoSwitched\": true, \"deliveryDate\": \"2026-11-15\", \"estimatedDelivery\": \"Lunch on 2026-11-15\"}, \"message\": \"Order placed\"}',4,'2026-11-15 22:23:36.270','2026-11-14 22:23:36.270','2026-11-14 22:23:36.313'),(23,1,'fc077c13-b0af-41e9-8205-5f6004781a77','c93bf9b2064b0bdf5e15f5769ad20d40dc2aaafdc1bc613abc6a59ea50863a01','COMPLETED',409,'{\"code\": \"ORDER_DUPLICATE\", \"data\": {\"existingOrderId\": 4, \"existingOrderNo\": \"WB20261115-0004\"}, \"message\": \"An active order already exists for this meal\"}',NULL,'2026-11-15 22:23:36.451','2026-11-14 22:23:36.451','2026-11-14 22:23:36.462'),(24,2,'g3-1794666287-timeout','f200ca68f0552c68798f9a236bd11bf601615b75b20557bcbb2d9afac0d57add','COMPLETED',201,'{\"code\": \"OK\", \"data\": {\"status\": \"Pending\", \"address\": \"Timeout Test Address\", \"orderId\": 5, \"orderNo\": \"WB20261115-0005\", \"mealType\": \"Lunch\", \"itemCount\": 1, \"totalCents\": 3000, \"autoSwitched\": false, \"deliveryDate\": \"2026-11-15\", \"estimatedDelivery\": \"Lunch on 2026-11-15\"}, \"message\": \"Order placed\"}',5,'2026-11-15 22:24:47.919','2026-11-14 22:24:47.919','2026-11-14 22:24:47.951'),(25,1,'834fe989-9cc9-4208-aeba-d5bfa7439e75','cb5ab287a5182f997c077e6a5fbe60b04cf5a9691c686fd4058ba079501c24b7','COMPLETED',201,'{\"code\": \"OK\", \"data\": {\"status\": \"Pending\", \"address\": \"Building A, 12F\", \"orderId\": 6, \"orderNo\": \"WB20261115-0006\", \"mealType\": \"Lunch\", \"itemCount\": 2, \"totalCents\": 5600, \"autoSwitched\": true, \"deliveryDate\": \"2026-11-15\", \"estimatedDelivery\": \"Lunch on 2026-11-15\"}, \"message\": \"Order placed\"}',6,'2026-11-15 22:25:42.603','2026-11-14 22:25:42.603','2026-11-14 22:25:42.623'),(26,2,'g3-1794666287-redis','27e989168158f807e04240453092c260c561837d863d676fd3ef7ac404904087','COMPLETED',400,'{\"code\": \"VALIDATION_OPTION_REQUIRED\", \"data\": null, \"message\": \"Group \'Bun\' requires a selection\"}',NULL,'2026-11-15 22:26:58.093','2026-11-14 22:26:58.093','2026-11-14 22:26:58.104'),(27,2,'g3redis-1794666485','fe2c08ebadac6c0a737306c8128cb6412c685b6acd5b1041a33b24213c024c01','COMPLETED',400,'{\"code\": \"VALIDATION_OPTION_REQUIRED\", \"data\": null, \"message\": \"Group \'Base\' requires a selection\"}',NULL,'2026-11-15 22:28:05.331','2026-11-14 22:28:05.331','2026-11-14 22:28:05.367'),(28,2,'g3redis2-1794666495','3bf3ac7407ee192ec8df17441e37607f08924d3fddf5ce3a2a4dd76010d144be','COMPLETED',201,'{\"code\": \"OK\", \"data\": {\"status\": \"Pending\", \"address\": \"Redis Compensation Test\", \"orderId\": 7, \"orderNo\": \"WB20261115-0007\", \"mealType\": \"Lunch\", \"itemCount\": 2, \"totalCents\": 6600, \"autoSwitched\": false, \"deliveryDate\": \"2026-11-15\", \"estimatedDelivery\": \"Lunch on 2026-11-15\"}, \"message\": \"Order placed\"}',7,'2026-11-15 22:28:15.577','2026-11-14 22:28:15.577','2026-11-14 22:28:15.613'),(29,2,'g3redis3-1794666503','3bf3ac7407ee192ec8df17441e37607f08924d3fddf5ce3a2a4dd76010d144be','COMPLETED',409,'{\"code\": \"STOCK_INSUFFICIENT\", \"data\": {\"details\": [{\"dishId\": 11, \"available\": 0, \"requested\": 1}]}, \"message\": \"Some dishes are sold out or insufficient\"}',NULL,'2026-11-15 22:28:23.833','2026-11-14 22:28:23.833','2026-11-14 22:28:23.846'),(30,2,'adminflow-1794667055','edc57bc89ba5a1bc6aca20dcf427a6ecdd1ab1dd499bd1dcd779c2eb2b528fc4','COMPLETED',201,'{\"code\": \"OK\", \"data\": {\"status\": \"Pending\", \"address\": \"Admin Flow Test\", \"orderId\": 8, \"orderNo\": \"WB20261115-0008\", \"mealType\": \"Lunch\", \"itemCount\": 1, \"totalCents\": 3000, \"autoSwitched\": false, \"deliveryDate\": \"2026-11-15\", \"estimatedDelivery\": \"Lunch on 2026-11-15\"}, \"message\": \"Order placed\"}',8,'2026-11-15 22:37:35.080','2026-11-14 22:37:35.080','2026-11-14 22:37:35.113'),(31,110,'pa-k1-1794667288','e5a0e921277db2d6c8ff4b457201a69eb873c6245d56e39b2aad42f2102be184','COMPLETED',201,'{\"code\": \"OK\", \"data\": {\"status\": \"Pending\", \"address\": \"Building A, 12F\", \"orderId\": 9, \"orderNo\": \"WB20261115-0009\", \"mealType\": \"Lunch\", \"itemCount\": 2, \"totalCents\": 8200, \"autoSwitched\": false, \"deliveryDate\": \"2026-11-15\", \"estimatedDelivery\": \"Lunch on 2026-11-15\"}, \"message\": \"Order placed\"}',9,'2026-11-15 22:41:28.131','2026-11-14 22:41:28.131','2026-11-14 22:41:28.158'),(36,110,'pa-dup-1794667288','f6d1a4b1081d94d4f672c509770337afc47899093b38218a9e711ae471ab6dbf','COMPLETED',409,'{\"code\": \"ORDER_DUPLICATE\", \"data\": {\"existingOrderId\": 9, \"existingOrderNo\": \"WB20261115-0009\"}, \"message\": \"An active order already exists for this meal\"}',NULL,'2026-11-15 22:41:28.479','2026-11-14 22:41:28.479','2026-11-14 22:41:28.508'),(37,112,'pa2-q6-1794667308','490a1618f119bc567fa23501c3b4a11bc9049ea11a10451f53a9ba435bff95be','COMPLETED',400,'{\"code\": \"ORDER_LIMIT_EXCEEDED\", \"data\": null, \"message\": \"At most 5 portions per order\"}',NULL,'2026-11-15 22:41:48.790','2026-11-14 22:41:48.790','2026-11-14 22:41:48.797'),(38,112,'pa2-q5-1794667308','ef867f93762631c668c4e5d6f8b7d0f29a0acda0f82a82275934a777875b4715','COMPLETED',201,'{\"code\": \"OK\", \"data\": {\"status\": \"Pending\", \"address\": \"Building A\", \"orderId\": 10, \"orderNo\": \"WB20261115-0010\", \"mealType\": \"Lunch\", \"itemCount\": 5, \"totalCents\": 14100, \"autoSwitched\": false, \"deliveryDate\": \"2026-11-15\", \"estimatedDelivery\": \"Lunch on 2026-11-15\"}, \"message\": \"Order placed\"}',10,'2026-11-15 22:41:48.835','2026-11-14 22:41:48.835','2026-11-14 22:41:48.858'),(39,1,'a235f0ed-3a70-4762-ba3a-67ea1447596c','7e3a2922f8246d01a2a8568b69ac19eab558497896d5a7d27d80a8223a010301','IN_PROGRESS',NULL,NULL,NULL,'2026-11-15 22:44:49.078','2026-11-14 22:44:49.078','2026-11-14 22:44:49.078'),(41,2,'c4814869-d284-43b3-9909-943fe7b5bae0','efb9ebed3f9872e6d3bd429b716b03b673f815e0d2adb6ebe3e6c5211458b5c6','IN_PROGRESS',NULL,NULL,NULL,'2026-11-15 22:46:33.012','2026-11-14 22:46:33.013','2026-11-14 22:46:33.013'),(42,2,'s5b-rate-1-1794667884','0797fa73337474719e91b5e8f8621c8623455b53aa98eeedf91b3b079fe9f24e','COMPLETED',400,'{\"code\": \"VALIDATION_OPTION_REQUIRED\", \"data\": null, \"message\": \"Group \'Base\' requires a selection\"}',NULL,'2026-11-15 22:51:24.493','2026-11-14 22:51:24.493','2026-11-14 22:51:24.506'),(43,2,'s5b-rate-2-1794667884','0797fa73337474719e91b5e8f8621c8623455b53aa98eeedf91b3b079fe9f24e','COMPLETED',400,'{\"code\": \"VALIDATION_OPTION_REQUIRED\", \"data\": null, \"message\": \"Group \'Base\' requires a selection\"}',NULL,'2026-11-15 22:51:24.540','2026-11-14 22:51:24.540','2026-11-14 22:51:24.546'),(44,2,'s5b-rate-3-1794667884','0797fa73337474719e91b5e8f8621c8623455b53aa98eeedf91b3b079fe9f24e','COMPLETED',400,'{\"code\": \"VALIDATION_OPTION_REQUIRED\", \"data\": null, \"message\": \"Group \'Base\' requires a selection\"}',NULL,'2026-11-15 22:51:24.579','2026-11-14 22:51:24.579','2026-11-14 22:51:24.586'),(45,2,'s5b-rate-4-1794667884','0797fa73337474719e91b5e8f8621c8623455b53aa98eeedf91b3b079fe9f24e','COMPLETED',400,'{\"code\": \"VALIDATION_OPTION_REQUIRED\", \"data\": null, \"message\": \"Group \'Base\' requires a selection\"}',NULL,'2026-11-15 22:51:24.618','2026-11-14 22:51:24.618','2026-11-14 22:51:24.625'),(46,2,'s5b-rate-5-1794667884','0797fa73337474719e91b5e8f8621c8623455b53aa98eeedf91b3b079fe9f24e','COMPLETED',400,'{\"code\": \"VALIDATION_OPTION_REQUIRED\", \"data\": null, \"message\": \"Group \'Base\' requires a selection\"}',NULL,'2026-11-15 22:51:24.657','2026-11-14 22:51:24.657','2026-11-14 22:51:24.663');
/*!40000 ALTER TABLE `idempotency_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_ledger`
--

DROP TABLE IF EXISTS `inventory_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_ledger` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned DEFAULT NULL,
  `dish_id` bigint unsigned NOT NULL,
  `serve_date` date NOT NULL,
  `entry_type` enum('RESERVE','RELEASE','CONFIRM','ADJUST') NOT NULL,
  `qty` int NOT NULL,
  `before_available` int NOT NULL,
  `after_available` int NOT NULL,
  `business_key` varchar(120) NOT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ledger_business_key` (`business_key`),
  KEY `idx_ledger_order` (`order_id`),
  KEY `idx_ledger_dish_date` (`dish_id`,`serve_date`),
  KEY `idx_ledger_created` (`created_at`),
  CONSTRAINT `fk_ledger_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `ck_ledger_qty` CHECK ((`qty` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_ledger`
--

LOCK TABLES `inventory_ledger` WRITE;
/*!40000 ALTER TABLE `inventory_ledger` DISABLE KEYS */;
INSERT INTO `inventory_ledger` VALUES (4,3,9,'2026-11-15','RESERVE',1,30,29,'ORD:3:D:9:RESERVE','employee@webox.com',NULL,'2026-11-14 22:20:43.727'),(5,3,9,'2026-11-15','RELEASE',1,29,30,'ORD:3:D:9:RELEASE','employee@webox.com','CANCELLED','2026-11-14 22:20:43.876'),(6,4,11,'2026-11-15','RESERVE',2,40,38,'ORD:4:D:11:RESERVE','admin@webox.com',NULL,'2026-11-14 22:23:36.307'),(7,4,11,'2026-11-15','RELEASE',2,38,40,'ORD:4:D:11:RELEASE','admin@webox.com','FE integration test','2026-11-14 22:23:36.575'),(8,5,17,'2026-11-15','RESERVE',1,40,39,'ORD:5:D:17:RESERVE','employee@webox.com',NULL,'2026-11-14 22:24:47.946'),(9,5,17,'2026-11-15','RELEASE',1,39,40,'ORD:5:D:17:RELEASE','SYSTEM','TIMEOUT','2026-11-14 22:25:13.277'),(10,6,11,'2026-11-15','RESERVE',2,40,38,'ORD:6:D:11:RESERVE','admin@webox.com',NULL,'2026-11-14 22:25:42.613'),(11,7,9,'2026-11-15','RESERVE',1,30,29,'ORD:7:D:9:RESERVE','employee@webox.com',NULL,'2026-11-14 22:28:15.602'),(12,7,11,'2026-11-15','RESERVE',1,38,37,'ORD:7:D:11:RESERVE','employee@webox.com',NULL,'2026-11-14 22:28:15.603'),(13,7,9,'2026-11-15','RELEASE',1,29,30,'ORD:7:D:9:RELEASE','employee@webox.com','CANCELLED','2026-11-14 22:28:23.776'),(14,7,11,'2026-11-15','RELEASE',1,37,38,'ORD:7:D:11:RELEASE','employee@webox.com','CANCELLED','2026-11-14 22:28:23.778'),(15,6,11,'2026-11-15','RELEASE',2,38,40,'ORD:6:D:11:RELEASE','admin@webox.com','Frontend UI integration test cleanup','2026-11-14 22:28:25.280'),(16,8,17,'2026-11-15','RESERVE',1,40,39,'ORD:8:D:17:RESERVE','employee@webox.com',NULL,'2026-11-14 22:37:35.108'),(17,8,17,'2026-11-15','CONFIRM',1,39,39,'ORD:8:D:17:CONFIRM','admin','kitchen accepted','2026-11-14 22:37:35.171'),(18,9,9,'2026-11-15','RESERVE',2,30,28,'ORD:9:D:9:RESERVE','pa_1794667287_a@test.com',NULL,'2026-11-14 22:41:28.153'),(19,9,9,'2026-11-15','RELEASE',2,28,30,'ORD:9:D:9:RELEASE','pa_1794667287_a@test.com','changed mind','2026-11-14 22:41:28.584'),(20,10,2,'2026-11-15','RESERVE',2,40,38,'ORD:10:D:2:RESERVE','pa2_1794667308@test.com',NULL,'2026-11-14 22:41:48.847'),(21,10,11,'2026-11-15','RESERVE',3,40,37,'ORD:10:D:11:RESERVE','pa2_1794667308@test.com',NULL,'2026-11-14 22:41:48.847'),(22,10,2,'2026-11-15','CONFIRM',2,38,38,'ORD:10:D:2:CONFIRM','admin','kitchen accepted','2026-11-14 22:41:48.924'),(23,10,11,'2026-11-15','CONFIRM',3,37,37,'ORD:10:D:11:CONFIRM','admin','kitchen accepted','2026-11-14 22:41:48.925'),(24,11,1,'2026-11-15','RESERVE',5,40,35,'ORD:11:D:1:RESERVE','admin@webox.com',NULL,'2026-11-14 22:44:49.087'),(25,12,11,'2026-11-15','RESERVE',5,37,32,'ORD:12:D:11:RESERVE','employee@webox.com',NULL,'2026-11-14 22:46:33.021');
/*!40000 ALTER TABLE `inventory_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `dish_id` bigint unsigned NOT NULL,
  `dish_name` varchar(100) NOT NULL,
  `unit_price_cents` bigint NOT NULL,
  `options_json` json DEFAULT NULL,
  `qty` int NOT NULL,
  `subtotal_cents` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_order` (`order_id`),
  CONSTRAINT `fk_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `ck_items_qty` CHECK ((`qty` >= 1)),
  CONSTRAINT `ck_items_subtotal` CHECK ((`subtotal_cents` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (3,3,9,'Classic Beef Burger',3800,'[{\"name\": \"Plain\", \"priceDeltaCents\": 0}, {\"name\": \"Ketchup\", \"priceDeltaCents\": 0}]',1,3800),(4,4,11,'Beef Noodle Soup',2800,'[]',2,5600),(5,5,17,'Mushroom Risotto',3000,'[]',1,3000),(6,6,11,'Beef Noodle Soup',2800,'[]',2,5600),(7,7,9,'Classic Beef Burger',3800,'[{\"name\": \"Plain\", \"priceDeltaCents\": 0}, {\"name\": \"Ketchup\", \"priceDeltaCents\": 0}]',1,3800),(8,7,11,'Beef Noodle Soup',2800,'[]',1,2800),(9,8,17,'Mushroom Risotto',3000,'[]',1,3000),(10,9,9,'Classic Beef Burger',4100,'[{\"name\": \"Whole Wheat\", \"priceDeltaCents\": 0}, {\"name\": \"Mustard\", \"priceDeltaCents\": 0}, {\"name\": \"Cheese\", \"priceDeltaCents\": 300}]',2,8200),(11,10,11,'Beef Noodle Soup',2800,'[]',3,8400),(12,10,2,'Caesar Salad',2850,'[]',2,5700),(13,11,1,'Kung Pao Chicken',2200,'[]',5,11000),(14,12,11,'Beef Noodle Soup',2800,'[]',5,14000);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(24) NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `status` enum('Pending','Confirmed','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  `delivery_date` date NOT NULL,
  `meal_type` enum('Lunch','Dinner') NOT NULL,
  `address` varchar(200) NOT NULL,
  `total_cents` bigint NOT NULL,
  `item_count` int NOT NULL,
  `budget_exceeded` tinyint(1) NOT NULL DEFAULT '0',
  `idempotency_key` varchar(64) DEFAULT NULL,
  `snapshot_json` json NOT NULL,
  `cancel_reason` varchar(200) DEFAULT NULL,
  `cancelled_at` datetime(3) DEFAULT NULL,
  `active_key` varchar(80) GENERATED ALWAYS AS ((case when (`status` in (_utf8mb4'Pending',_utf8mb4'Confirmed')) then concat(`user_id`,_utf8mb4':',`delivery_date`,_utf8mb4':',`meal_type`) else NULL end)) STORED,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_orders_no` (`order_no`),
  UNIQUE KEY `uk_orders_active` (`active_key`),
  UNIQUE KEY `uk_orders_idem` (`user_id`,`idempotency_key`),
  KEY `idx_orders_user_created` (`user_id`,`created_at`),
  KEY `idx_orders_date_meal_status` (`delivery_date`,`meal_type`,`status`),
  CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `ck_orders_count` CHECK ((`item_count` between 1 and 5)),
  CONSTRAINT `ck_orders_total` CHECK ((`total_cents` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`id`, `order_no`, `user_id`, `status`, `delivery_date`, `meal_type`, `address`, `total_cents`, `item_count`, `budget_exceeded`, `idempotency_key`, `snapshot_json`, `cancel_reason`, `cancelled_at`, `created_at`, `updated_at`) VALUES (3,'WB20261115-0003',2,'Cancelled','2026-11-15','Lunch','Building A, 12F',3800,1,0,'smoke-key-1794666043-01','{\"items\": [{\"qty\": 1, \"dishId\": 9, \"options\": [{\"name\": \"Plain\", \"priceDeltaCents\": 0}, {\"name\": \"Ketchup\", \"priceDeltaCents\": 0}], \"dishName\": \"Classic Beef Burger\", \"subtotalCents\": 3800, \"unitPriceCents\": 3800}], \"address\": \"Building A, 12F\", \"mealType\": \"Lunch\", \"createdAt\": \"2026-11-14T22:20:43.686803526+08:00\", \"totalCents\": 3800, \"deliveryDate\": \"2026-11-15\"}',NULL,'2026-11-14 22:20:43.874','2026-11-14 22:20:43.695','2026-11-14 22:20:43.874'),(4,'WB20261115-0004',1,'Cancelled','2026-11-15','Lunch','Building A, 12F (FE integration)',5600,2,0,'8cb15ade-d8b5-4d97-8d25-cd8c159632af','{\"items\": [{\"qty\": 2, \"dishId\": 11, \"options\": [], \"dishName\": \"Beef Noodle Soup\", \"subtotalCents\": 5600, \"unitPriceCents\": 2800}], \"address\": \"Building A, 12F (FE integration)\", \"mealType\": \"Lunch\", \"createdAt\": \"2026-11-14T22:23:36.294784365+08:00\", \"totalCents\": 5600, \"deliveryDate\": \"2026-11-15\"}','FE integration test','2026-11-14 22:23:36.572','2026-11-14 22:23:36.297','2026-11-14 22:23:36.572'),(5,'WB20261115-0005',2,'Cancelled','2026-11-15','Lunch','Timeout Test Address',3000,1,0,'g3-1794666287-timeout','{\"items\": [{\"qty\": 1, \"dishId\": 17, \"options\": [], \"dishName\": \"Mushroom Risotto\", \"subtotalCents\": 3000, \"unitPriceCents\": 3000}], \"address\": \"Timeout Test Address\", \"mealType\": \"Lunch\", \"createdAt\": \"2026-11-14T22:24:47.935260558+08:00\", \"totalCents\": 3000, \"deliveryDate\": \"2026-11-15\"}','TIMEOUT','2026-11-14 22:25:13.275','2026-11-14 21:53:47.937','2026-11-14 22:25:13.275'),(6,'WB20261115-0006',1,'Cancelled','2026-11-15','Lunch','Building A, 12F',5600,2,0,'834fe989-9cc9-4208-aeba-d5bfa7439e75','{\"items\": [{\"qty\": 2, \"dishId\": 11, \"options\": [], \"dishName\": \"Beef Noodle Soup\", \"subtotalCents\": 5600, \"unitPriceCents\": 2800}], \"address\": \"Building A, 12F\", \"mealType\": \"Lunch\", \"createdAt\": \"2026-11-14T22:25:42.611004583+08:00\", \"totalCents\": 5600, \"deliveryDate\": \"2026-11-15\"}','Frontend UI integration test cleanup','2026-11-14 22:28:25.279','2026-11-14 22:25:42.611','2026-11-14 22:28:25.279'),(7,'WB20261115-0007',2,'Cancelled','2026-11-15','Lunch','Redis Compensation Test',6600,2,0,'g3redis2-1794666495','{\"items\": [{\"qty\": 1, \"dishId\": 9, \"options\": [{\"name\": \"Plain\", \"priceDeltaCents\": 0}, {\"name\": \"Ketchup\", \"priceDeltaCents\": 0}], \"dishName\": \"Classic Beef Burger\", \"subtotalCents\": 3800, \"unitPriceCents\": 3800}, {\"qty\": 1, \"dishId\": 11, \"options\": [], \"dishName\": \"Beef Noodle Soup\", \"subtotalCents\": 2800, \"unitPriceCents\": 2800}], \"address\": \"Redis Compensation Test\", \"mealType\": \"Lunch\", \"createdAt\": \"2026-11-14T22:28:15.593288510+08:00\", \"totalCents\": 6600, \"deliveryDate\": \"2026-11-15\"}',NULL,'2026-11-14 22:28:23.773','2026-11-14 22:28:15.597','2026-11-14 22:28:23.773'),(8,'WB20261115-0008',2,'Completed','2026-11-15','Lunch','Admin Flow Test',3000,1,0,'adminflow-1794667055','{\"items\": [{\"qty\": 1, \"dishId\": 17, \"options\": [], \"dishName\": \"Mushroom Risotto\", \"subtotalCents\": 3000, \"unitPriceCents\": 3000}], \"address\": \"Admin Flow Test\", \"mealType\": \"Lunch\", \"createdAt\": \"2026-11-14T22:37:35.096788109+08:00\", \"totalCents\": 3000, \"deliveryDate\": \"2026-11-15\"}',NULL,NULL,'2026-11-14 22:37:35.099','2026-11-14 22:37:35.216'),(9,'WB20261115-0009',110,'Cancelled','2026-11-15','Lunch','Building A, 12F',8200,2,0,'pa-k1-1794667288','{\"items\": [{\"qty\": 2, \"dishId\": 9, \"options\": [{\"name\": \"Whole Wheat\", \"priceDeltaCents\": 0}, {\"name\": \"Mustard\", \"priceDeltaCents\": 0}, {\"name\": \"Cheese\", \"priceDeltaCents\": 300}], \"dishName\": \"Classic Beef Burger\", \"subtotalCents\": 8200, \"unitPriceCents\": 4100}], \"address\": \"Building A, 12F\", \"mealType\": \"Lunch\", \"createdAt\": \"2026-11-14T22:41:28.143314126+08:00\", \"totalCents\": 8200, \"deliveryDate\": \"2026-11-15\"}','changed mind','2026-11-14 22:41:28.582','2026-11-14 22:41:28.147','2026-11-14 22:41:28.582'),(10,'WB20261115-0010',112,'Confirmed','2026-11-15','Lunch','Building A',14100,5,0,'pa2-q5-1794667308','{\"items\": [{\"qty\": 3, \"dishId\": 11, \"options\": [], \"dishName\": \"Beef Noodle Soup\", \"subtotalCents\": 8400, \"unitPriceCents\": 2800}, {\"qty\": 2, \"dishId\": 2, \"options\": [], \"dishName\": \"Caesar Salad\", \"subtotalCents\": 5700, \"unitPriceCents\": 2850}], \"address\": \"Building A\", \"mealType\": \"Lunch\", \"createdAt\": \"2026-11-14T22:41:48.844870198+08:00\", \"totalCents\": 14100, \"deliveryDate\": \"2026-11-15\"}',NULL,NULL,'2026-11-14 22:41:48.845','2026-11-14 22:41:48.922'),(11,'WB20261115-0011',1,'Pending','2026-11-15','Lunch','Building A, 12F',11000,5,0,'a235f0ed-3a70-4762-ba3a-67ea1447596c','{\"items\": [{\"qty\": 5, \"dishId\": 1, \"options\": [], \"dishName\": \"Kung Pao Chicken\", \"subtotalCents\": 11000, \"unitPriceCents\": 2200}], \"address\": \"Building A, 12F\", \"mealType\": \"Lunch\", \"createdAt\": \"2026-11-14T22:44:49.085387686+08:00\", \"totalCents\": 11000, \"deliveryDate\": \"2026-11-15\"}',NULL,NULL,'2026-11-14 22:44:49.085','2026-11-14 22:44:49.086'),(12,'WB20261115-0012',2,'Pending','2026-11-15','Lunch','Office 1F, Test Street',14000,5,1,'c4814869-d284-43b3-9909-943fe7b5bae0','{\"items\": [{\"qty\": 5, \"dishId\": 11, \"options\": [], \"dishName\": \"Beef Noodle Soup\", \"subtotalCents\": 14000, \"unitPriceCents\": 2800}], \"address\": \"Office 1F, Test Street\", \"mealType\": \"Lunch\", \"createdAt\": \"2026-11-14T22:46:33.019559449+08:00\", \"totalCents\": 14000, \"deliveryDate\": \"2026-11-15\"}',NULL,NULL,'2026-11-14 22:46:33.020','2026-11-14 22:46:33.020');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_tokens`
--

DROP TABLE IF EXISTS `refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `revoked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_rt_hash` (`token_hash`),
  KEY `idx_rt_user` (`user_id`,`expires_at`),
  CONSTRAINT `fk_rt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_tokens`
--

LOCK TABLES `refresh_tokens` WRITE;
/*!40000 ALTER TABLE `refresh_tokens` DISABLE KEYS */;
INSERT INTO `refresh_tokens` VALUES (1,2,'0c0a24220d990d389b450832663768e11bab64772b599d854ffdeb7ea7be6db2','2026-11-21 22:18:04.560',0,'2026-11-14 22:18:04.562'),(2,1,'3184ab18438d2a43358fc45c870d51cdb32da0193d948f0b54607e4b394927e9','2026-11-21 22:18:04.655',0,'2026-11-14 22:18:04.655'),(3,2,'24c80d4c152c3521b219d5c8f0d948aab33a65442276163b15cac12e8fbd296a','2026-11-21 22:18:18.435',0,'2026-11-14 22:18:18.435'),(4,1,'3ff8bbdf8d8a86fcdeae353b44037541839f4c8cc80e0e823cc9ed933dde837e','2026-11-21 22:18:18.867',0,'2026-11-14 22:18:18.867'),(5,2,'5202590a428ff481d1c8baeaad5f7c4f5b122a7c1f602df0908b26e1f1fb707b','2026-11-21 22:18:54.815',0,'2026-11-14 22:18:54.817'),(6,1,'9bb8f84239f58878bb5f143bc6edc9b7ace57b45f6017a587d3ad8e4755b7622','2026-11-21 22:18:55.274',0,'2026-11-14 22:18:55.274'),(7,2,'74a43aa3999c5e4e8740f08865c9041041740181bf9a90b9a8e8f32431a6fa9a','2026-11-21 22:20:05.823',0,'2026-11-14 22:20:05.825'),(8,1,'2d990427e1075ba92e36d9122630b112cd3c4762fd30604c03686f1658f966aa','2026-11-21 22:20:06.257',0,'2026-11-14 22:20:06.257'),(9,2,'b18f231be19868671933d151a8bfc64073e07c5fbf9fe13cf7dff7d54ac072ed','2026-11-21 22:20:43.485',0,'2026-11-14 22:20:43.486'),(10,1,'e749cc05c2985f4ee87ce2330fbaec2351fc456f48879ff72693188611726260','2026-11-21 22:20:43.985',0,'2026-11-14 22:20:43.985'),(11,1,'62bf3c16eed28986b52df78ed2a02e08b2eb217f00e299851d25be3ed3cd5be3','2026-11-21 22:23:25.721',0,'2026-11-14 22:23:25.723'),(12,1,'c146168f7c84dcf4f2e73ca330582267ced9a4f7cc571ecbb50716d7cc3c7817','2026-11-21 22:23:36.131',0,'2026-11-14 22:23:36.131'),(13,2,'551b3f355ba77394fa6e0c86219e513c7ad6edaee54ea16e3b790822d85a971c','2026-11-21 22:23:36.771',0,'2026-11-14 22:23:36.771'),(14,1,'65026bf3587785076dfa7d72fa61133732446017b39d25702beed23004c90dd8','2026-11-21 22:23:46.292',0,'2026-11-14 22:23:46.292'),(15,1,'dcd1c45ef1dcc32557f2e2071511f1d7f4d3407552cd3c0613bd18cbe138cc41','2026-11-21 22:24:23.310',0,'2026-11-14 22:24:23.310'),(16,1,'20cb387a5e2bb24991cca0b0c0d137fc65ff83aaa57c7710f686412817fbb2cf','2026-11-21 22:24:30.158',0,'2026-11-14 22:24:30.158'),(17,2,'a9f46ac16e37a9dbc1e71744b674d6de0a5a7ef605175d5d4440f4052834bf6a','2026-11-21 22:24:47.734',0,'2026-11-14 22:24:47.735'),(18,1,'6fa5be595a64fd4a79dd4ef389788c28f714bebd119952fd4b817a43812ef091','2026-11-21 22:24:47.830',0,'2026-11-14 22:24:47.830'),(19,1,'cd814b9eea0c323adc64ec256177f1def54b37510c0e1bbddb62abd4f6aa851d','2026-11-21 22:25:10.337',0,'2026-11-14 22:25:10.337'),(20,1,'417de6818bd50e4e9b524dbef89f35f44d7a301dba9bb7c9412703a7a280c6a5','2026-11-21 22:25:17.857',0,'2026-11-14 22:25:17.857'),(21,2,'361d3bbcd15a6aea5343170ced691d8e94b48a8967dc10086e4362cdf0b28a48','2026-11-21 22:27:18.430',0,'2026-11-14 22:27:18.430'),(22,2,'1476b8b88ad6d5f8a7691cb9a9650b9b968b119b864512de41c587bcb159e2a1','2026-11-21 22:28:05.191',0,'2026-11-14 22:28:05.193'),(23,2,'00c9ca701e26b46fd65bb718f37dffb369e20e1b5a1b3eb29b01616efefbb400','2026-11-21 22:28:15.509',0,'2026-11-14 22:28:15.509'),(24,2,'d70dcbda0acbd0b8c460cb11be6a6e66b7852d0f0cb566424b14aba5a1f07006','2026-11-21 22:28:23.748',0,'2026-11-14 22:28:23.748'),(25,1,'b40602e2510726ea891b7ba815458878fcb3329b3bcb02241e9535deba2387cf','2026-11-21 22:28:25.251',0,'2026-11-14 22:28:25.251'),(26,2,'816cce4ab11d4e8adbc34b6796b6af948b00c7399021ade48108c0420cd416c3','2026-11-21 22:32:38.573',0,'2026-11-14 22:32:38.574'),(27,2,'76c5d3180c3b8513f393b7e7cbd8abc22e840d29052970859c56625cbb9ae5e9','2026-11-21 22:36:58.144',0,'2026-11-14 22:36:58.144'),(28,2,'be992bca774a61ed2198771e40df8185a4639656be69326b656aaa103db46321','2026-11-21 22:37:34.898',0,'2026-11-14 22:37:34.899'),(29,1,'5901082ffd514ddc43d1b8a404fd1991ec05a53b762365c9b116bef959b822a9','2026-11-21 22:37:34.996',0,'2026-11-14 22:37:34.996'),(30,1,'4a0f52e8b6c6c8e82c9b6288693b63fa6cc72c5da3b22d3a08adc2ae1e440a68','2026-11-21 22:39:21.114',0,'2026-11-14 22:39:21.114'),(31,1,'14388d3e328cff4873e50902db27f3c3bfd5ab4827766310cfcfce988d4deb8e','2026-11-21 22:39:51.650',0,'2026-11-14 22:39:51.650'),(32,7,'1ecf6428f7bf166ebea5d67bb6ceba780dbed5abb30dbb40017cb17ab7bb3830','2026-11-21 22:39:51.774',0,'2026-11-14 22:39:51.774'),(33,8,'7fa0469d137517161843970f4dda48b5bc8e9e6a9fcaad2c91112f9ec3ac260e','2026-11-21 22:39:51.852',0,'2026-11-14 22:39:51.852'),(34,9,'8d840f06ce0022b87fa34d7fc43dbc12935585add1b42dd41bca9644f7312e46','2026-11-21 22:39:51.928',0,'2026-11-14 22:39:51.928'),(35,10,'1f3e3253897fe9ae5a1947fae4cfe8adbe5681c61f2875f6a21714d7555f7825','2026-11-21 22:39:52.005',0,'2026-11-14 22:39:52.005'),(36,11,'803b518bb8215b33cb001804813bd449f0e1788542803894a787c8f7dd4a41ee','2026-11-21 22:39:52.084',0,'2026-11-14 22:39:52.083'),(37,12,'d151b52cc77ee05ccebc4c91f80860b269e7d4f79724166433def98de527ac67','2026-11-21 22:39:52.162',0,'2026-11-14 22:39:52.162'),(38,13,'2049287da6b49aa314cf7a110cacaa3782ed04ece36cb145cd2483652c22bedd','2026-11-21 22:39:52.238',0,'2026-11-14 22:39:52.238'),(39,14,'f7f09edfc23d643df5df60776dd370613c2ea496e335b6ce88d9eac34c77c824','2026-11-21 22:39:52.316',0,'2026-11-14 22:39:52.316'),(40,15,'c40d5fa4a09ff73e0bb56ff8a8df40b8142843ba01b9b594367bcf72d7176029','2026-11-21 22:39:52.403',0,'2026-11-14 22:39:52.403'),(41,16,'fa1f1e14db8a9af06af5c5e8704ebdc8c1f697460f73da6109ecba414a9e21ac','2026-11-21 22:39:52.480',0,'2026-11-14 22:39:52.480'),(42,17,'bac3f93d99ebc1eeeb1ac5f8e8151a982752ddadc30252fcda529c25df2ba92c','2026-11-21 22:39:52.559',0,'2026-11-14 22:39:52.560'),(43,18,'6ba1845f1116a833fb796483208fc8fb2d759b4cb1fe98da7d7a13312b655298','2026-11-21 22:39:52.642',0,'2026-11-14 22:39:52.641'),(44,19,'c64eb6ea95e167d63dee68e5e64889247159cb201cefc6b3b7d36d9a5694b30b','2026-11-21 22:39:52.718',0,'2026-11-14 22:39:52.718'),(45,20,'b090e9c8674d3b5b9e92b5fbaa2885fad0c1e74b647e055a40c007748a2a0037','2026-11-21 22:39:52.798',0,'2026-11-14 22:39:52.798'),(46,21,'b84dc5de039449644e5076dcbde15df852e900a4160f0e9292c72fd297946531','2026-11-21 22:39:52.877',0,'2026-11-14 22:39:52.876'),(47,22,'1d6477eaa78dc592c42e6fcda801bdc0eb85e3a8187770c8e0896ad072947eb4','2026-11-21 22:39:52.954',0,'2026-11-14 22:39:52.953'),(48,23,'90ba4b426e27fa032a63f9f05f1db9cb7df0e707172f6df6c6b1f504359d8e49','2026-11-21 22:39:53.048',0,'2026-11-14 22:39:53.048'),(49,24,'37302580b90088429c6e50ab5f56ba8ae13177cc14b2c418a3168d36275f6742','2026-11-21 22:39:53.131',0,'2026-11-14 22:39:53.131'),(50,1,'137df14d2e14345f2d5137f8be0270b9b5530d0a5803a276630b6cb27f1f9fd9','2026-11-21 22:41:01.548',1,'2026-11-14 22:41:01.551'),(51,1,'a4e624cbf8f1c34490849ba2531edf9f8ce688e0c58d08a247f4d080621ac8d6','2026-11-21 22:41:01.956',0,'2026-11-14 22:41:01.956'),(52,2,'82f3e68b053dba4c3a872dcd4e8f6e62cdf1f1975aa45365698b5025d1e0c7d2','2026-11-21 22:41:16.857',1,'2026-11-14 22:41:16.859'),(53,1,'7416850257884644c9b00e1ac17f42c5eefab90333c094a4af3003a930215400','2026-11-21 22:41:17.038',0,'2026-11-14 22:41:17.039'),(54,2,'1bebf3badf50d3e7b00f8fc48c97aafdd43defbc1eb1ff753b3bbcf68c169d97','2026-11-21 22:41:17.098',0,'2026-11-14 22:41:17.098'),(55,1,'8e20a94d77f0637c53efb88179698e5b23728cda98a991b9e2b8284849e899c9','2026-11-21 22:41:18.789',0,'2026-11-14 22:41:18.791'),(56,109,'a672ac675702ad17757d3492f4672b8e01e9a6f5f5a0686a1046eeaa046b17bb','2026-11-21 22:41:24.121',1,'2026-11-14 22:41:24.121'),(57,109,'f40ee3b579c251edf96e016a0574dfc99fb84dd07853471c1ff8df0d63d7159b','2026-11-21 22:41:24.249',0,'2026-11-14 22:41:24.248'),(58,1,'889b1ac17bbc5f6cb1ae84fcab67e206306062d6da16258671d879b140b13155','2026-11-21 22:41:27.262',0,'2026-11-14 22:41:27.263'),(59,2,'47e333d3bf5c4ded57f3796700cf7067dc30add64df45652c643ff07679f1964','2026-11-21 22:41:27.398',0,'2026-11-14 22:41:27.398'),(60,110,'cd179cbfa14bad919c4896e8212ddc8efa47b00faae0ca4c02fabf5a67827ca1','2026-11-21 22:41:27.807',0,'2026-11-14 22:41:27.807'),(61,1,'ee10ab43eb9d3c363122bfa635f4269800ad43ee3c027c03d15d30fb574058d7','2026-11-21 22:41:33.525',0,'2026-11-14 22:41:33.525'),(63,2,'cebf694fd316999ee325fbda8a514c04c3edd0393f06fbf375f9f01788c711ea','2026-11-21 22:41:47.182',0,'2026-11-14 22:41:47.182'),(64,1,'2db16270bd07620a22d65e3a469dc8c86ffc5c064fa9fcae79e7a30b927dc052','2026-11-21 22:41:48.400',0,'2026-11-14 22:41:48.400'),(65,2,'d2350f420b940f115039cbd08717c4c209abed160d81a8fc79aac48008e8f1bf','2026-11-21 22:41:48.485',0,'2026-11-14 22:41:48.485'),(66,112,'4b94aa4b51ecf4eaa791ea2becb91325dedf98df3a54c6015453c364e47c277d','2026-11-21 22:41:48.692',0,'2026-11-14 22:41:48.692'),(67,113,'8155871d5ad783f257923454e5945339f1870c0e44e38b3c5a19d2525a90fbe8','2026-11-21 22:41:53.941',0,'2026-11-14 22:41:53.941'),(68,114,'c0bc7cf21ea1559043755185b10d885888def54a3592daaf7a2e2e6dbfb36162','2026-11-21 22:41:57.488',1,'2026-11-14 22:41:57.488'),(69,114,'eba728a57ce5eca838e928a01a28ef4833e040214cd27eee8332c22969a11b34','2026-11-21 22:41:57.573',0,'2026-11-14 22:41:57.573'),(71,113,'e49b86ab3882b67a70b624e4419585298785bf5c8d12676e8d0a474c8392f858','2026-11-21 22:41:57.709',0,'2026-11-14 22:41:57.709'),(72,2,'6c7c0178a8afe04b8829c237976149873b753f7400a72dbdc440e62aa714699d','2026-11-21 22:41:59.075',0,'2026-11-14 22:41:59.075'),(73,113,'450a40b86e9666784fd4de62b60b9df722737a4d4917124804c235f4b61978f4','2026-11-21 22:42:23.410',1,'2026-11-14 22:42:23.409'),(74,113,'7535c90c008aee3201400735d413221773f5187b2b89c088a10e8c36418832aa','2026-11-21 22:43:02.379',1,'2026-11-14 22:43:02.379'),(75,113,'39af17d579dd3573a048b312c70ca560ed3307d3d334611c50bdef61cf5e7270','2026-11-21 22:43:05.205',1,'2026-11-14 22:43:05.205'),(76,113,'2cc2069210867c91a7ef9a45201517cef0ab23efe16ef80b5d1fd1c1ba3f519c','2026-11-21 22:43:14.102',1,'2026-11-14 22:43:14.102'),(77,1,'d344451068a48702d3e2b195b39d52520bc391ad481a5cd645b0c42b300e5ddd','2026-11-21 22:43:16.785',0,'2026-11-14 22:43:16.785'),(78,1,'572eebcd2dcf26a08a7a53b0674e5180874781b2cfa58e3397c43f49f260c0a6','2026-11-21 22:43:23.119',0,'2026-11-14 22:43:23.121'),(79,113,'a4768dcae04856931f369d649ce733494424f7c06a0bbb59848c5f9fef62afdf','2026-11-21 22:43:25.877',1,'2026-11-14 22:43:25.877'),(80,1,'4fd64b7be99ed9e56ec4cef107b77f3cd531ee1cdeda8e59047ecba83f8a3617','2026-11-21 22:43:40.162',0,'2026-11-14 22:43:40.162'),(81,113,'66ca8c081ce701e1662064e4308dda4d28499c09d6d26632eaea77c6666e8570','2026-11-21 22:43:41.564',1,'2026-11-14 22:43:41.564'),(82,113,'f94e441dabd9c109bb974220e64f2dae2d9b35a52fbda45e316d54722631c788','2026-11-21 22:43:45.399',1,'2026-11-14 22:43:45.398'),(83,113,'9651e5fcf27ffdbea0c48daa286c57d3db69071272d9ad8aba7e80856e5e05d4','2026-11-21 22:43:53.356',0,'2026-11-14 22:43:53.356'),(84,1,'e2a5796ee5f0b7c84631fc12bf46b41d06c52c3818986e1a9d81106336d42c60','2026-11-21 22:43:57.911',1,'2026-11-14 22:43:57.911'),(85,1,'a6579aaf4909679384e2d83024ca853fd29fc480f86f18d03ef11e48fe8404c8','2026-11-21 22:44:01.763',1,'2026-11-14 22:44:01.762'),(86,1,'4b389455ae4dc6383cd11a659ccd8faa97176551435c519550298012dcf66707','2026-11-21 22:44:10.049',1,'2026-11-14 22:44:10.049'),(87,1,'d7dbd709f0d258170cfd585727e797b83075bf30571c13fa46f44de134b281b4','2026-11-21 22:44:21.283',1,'2026-11-14 22:44:21.283'),(88,1,'1a77cf796d63ff0aeee10db6a06ec4fd9b0e6fba7a1c6d8aec15bb7252f4568d','2026-11-21 22:44:36.087',1,'2026-11-14 22:44:36.087'),(89,1,'10108ad0eef3251d8dc34b3cd6fbbee31cdf6784affb726a230168835331e1bc','2026-11-21 22:44:38.961',1,'2026-11-14 22:44:38.961'),(90,1,'1f4029e3ccee87dfa96467f03f0a96d836ae98b3e3a6e06cf5476fcbdbd86a93','2026-11-21 22:45:50.633',0,'2026-11-14 22:45:50.634'),(91,2,'68a503b450567fff5ea7141adf79df4bd85f6b4c42d75a2b07bada1bf563ae1f','2026-11-21 22:45:51.864',0,'2026-11-14 22:45:51.864'),(92,1,'6406d0c871b332df4e3ba4855c52b4e85df4f705db630352233756848789fcf4','2026-11-21 22:45:56.465',1,'2026-11-14 22:45:56.464'),(93,2,'ff16679aba5043d6931a86a8a6afc53341e144b5eb2a340b129a83e785399749','2026-11-21 22:46:14.551',1,'2026-11-14 22:46:14.551'),(94,2,'f12c46e9b042aea466cd5d0098caccb52de9959158edfcbfe9e5dd9ba61c5d79','2026-11-21 22:46:17.886',1,'2026-11-14 22:46:17.885'),(95,2,'7776828ffc657e5fcf196e2a1700cbb69cf8c98e9b5b13c8199f04764da6c523','2026-11-21 22:46:19.752',1,'2026-11-14 22:46:19.751'),(96,1,'d453833fdc7bdf590066433ae8572307a3c8ccd0dddf75cf332efd33025aec94','2026-11-21 22:46:22.664',1,'2026-11-14 22:46:22.663'),(97,2,'f7cbf4c8eda1c4e3fb1f24aacdc60e979bc381effb0f56a4fa405a496ba2cbdd','2026-11-21 22:46:22.840',1,'2026-11-14 22:46:22.839'),(98,2,'b2330a5a877fb64a18df54ef93c77a5c7d0e2d196e578da25ea1b93fa130b317','2026-11-21 22:46:27.068',1,'2026-11-14 22:46:27.068'),(99,1,'39321a4434f993205e3c74e0ac3250c75760846d4d5c41819c3878d791a7383c','2026-11-21 22:46:31.960',1,'2026-11-14 22:46:31.960'),(100,1,'bd24832b29f8a6641a8dfc9339cd6ff5bd9256c9703e88a41d350c204005245d','2026-11-21 22:46:32.035',0,'2026-11-14 22:46:32.035'),(101,2,'ec56515e8d814ecf692acf77a71455282cdf72c72fa4e66dfbb1712a6d2e73da','2026-11-21 22:46:37.011',1,'2026-11-14 22:46:37.011'),(102,2,'9f78e03c39f34fb162abd463914d092e7a37d7ab974cf132155ae315f40b10fc','2026-11-21 22:46:39.383',1,'2026-11-14 22:46:39.383'),(103,1,'7e9e6939b7089357c80568c71ecf3a91a8abb8d225f11cee444b0e83468a9c07','2026-11-21 22:46:41.447',1,'2026-11-14 22:46:41.447'),(104,1,'19cd27bd2e381c6f2330bd785210ef3c22c1a3588c16499a63ac7ee33a2c4f90','2026-11-21 22:46:46.465',1,'2026-11-14 22:46:46.465'),(105,1,'f7fd56fbb71198e6c9106da066eba073a72722c6a0ef7e1d7192a220e1a0e70d','2026-11-21 22:46:46.594',0,'2026-11-14 22:46:46.594'),(106,1,'75ba902366732e671bace03183ab47f7c5a9577413ea0bef6aaa83a08e881637','2026-11-21 22:46:48.904',1,'2026-11-14 22:46:48.904'),(107,2,'c577c538165f78a05b5f5f9ae0617892b0d2e9cd9aa0ee311e5e10cbf538bd8f','2026-11-21 22:46:51.556',1,'2026-11-14 22:46:51.555'),(108,2,'7d0f55b373328dcd7efdd1cfaac998e7bc0c1f234bc33f0cbf46b3ad3806fcca','2026-11-21 22:46:53.414',1,'2026-11-14 22:46:53.414'),(109,2,'96865da2eb566c6788a497400879f012e9c4e69f8d872a207b8fe63872c3b7e8','2026-11-21 22:46:55.311',1,'2026-11-14 22:46:55.311'),(110,2,'4abec80b25b1cca32962995a742ad239eef624cb412e93c6bf826f1d8fdefa09','2026-11-21 22:46:57.215',0,'2026-11-14 22:46:57.214'),(111,2,'c7624424723d8c36c063c2593f6e27b2038e08cdb334d81955874dcac2dd73f4','2026-11-21 22:47:32.751',0,'2026-11-14 22:47:32.751'),(112,1,'93625a2aae27a75d47542bf5eac55a56a6b9120f2200430cb2580027858c9887','2026-11-21 22:47:33.661',1,'2026-11-14 22:47:33.661'),(113,1,'2d811849f7866940776feb6379a077bfcf50996141913dec43bfeadc6fe2c36f','2026-11-21 22:47:43.811',0,'2026-11-14 22:47:43.811'),(114,1,'6e7e311adf6f9c1113922c065645b5ec763309ddee0054250073f5f9e41d0075','2026-11-21 22:47:44.102',0,'2026-11-14 22:47:44.102'),(115,1,'027b55bf27b566c95d84e0ff30338dc9a869d3b15c8b38ded24c8391f605b458','2026-11-21 22:51:23.989',0,'2026-11-14 22:51:23.991'),(116,2,'53ce80d92681e624b7de751c4dbf38a789b99985c8b29a87e8eee9e9b13e1e67','2026-11-21 22:51:24.112',0,'2026-11-14 22:51:24.113'),(117,1,'e8962bd8a83369fed1e700663949b739f76fbaaa08b7e29293c780474cd20849','2026-11-21 22:51:39.405',0,'2026-11-14 22:51:39.405'),(118,1,'cc7eb181fb2da93e917dcdd0347a16dffdbe40019e856f2aba73f9f25b0933f1','2026-11-21 22:52:00.800',0,'2026-11-14 22:52:00.802');
/*!40000 ALTER TABLE `refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preferences`
--

DROP TABLE IF EXISTS `user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_preferences` (
  `user_id` bigint unsigned NOT NULL,
  `allergens` json DEFAULT NULL,
  `preferred_categories` json DEFAULT NULL,
  `spice_preference` enum('None','Mild','Medium','Hot') DEFAULT NULL,
  `taste_preference` enum('Light','Medium','Rich') DEFAULT NULL,
  `budget_min_cents` bigint DEFAULT NULL,
  `budget_max_cents` bigint DEFAULT NULL,
  `recommend_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_pref_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `ck_pref_budget` CHECK (((`budget_min_cents` is null) or (`budget_max_cents` is null) or ((`budget_min_cents` > 0) and (`budget_min_cents` <= `budget_max_cents`))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preferences`
--

LOCK TABLES `user_preferences` WRITE;
/*!40000 ALTER TABLE `user_preferences` DISABLE KEYS */;
INSERT INTO `user_preferences` VALUES (1,'[]','[]','None','Medium',100,1500,0,'2026-11-14 22:47:43.833'),(2,'[\"Peanuts\"]','[\"Chinese\"]','Mild','Medium',NULL,NULL,1,'2026-11-14 22:51:24.336'),(113,'[]','[]',NULL,NULL,NULL,NULL,0,'2026-11-14 22:43:25.425');
/*!40000 ALTER TABLE `user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profile` (
  `user_id` bigint unsigned NOT NULL,
  `order_count_30d` int NOT NULL DEFAULT '0',
  `favorite_categories` json DEFAULT NULL,
  `avg_spend_cents` bigint NOT NULL DEFAULT '0',
  `last_computed_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_profile_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
INSERT INTO `user_profile` VALUES (2,0,'[]',0,'2026-11-14 22:17:47.204');
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `password_hash` varchar(100) NOT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `role` enum('EMPLOYEE','ADMIN') NOT NULL DEFAULT 'EMPLOYEE',
  `status` enum('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `site_id` varchar(16) NOT NULL DEFAULT 'HQ',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_email` (`email`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@webox.com','$2b$10$tPTDIiDEm7wLmaCclGtbFuLqyP13aBM6Xu1rdo5SwiTT6QY7FBzbS','WeBox Admin','ADMIN','ACTIVE','HQ','2026-11-14 22:17:47.196','2026-11-14 22:17:47.196'),(2,'employee@webox.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq','Demo Employee','EMPLOYEE','ACTIVE','HQ','2026-11-14 22:17:47.196','2026-11-14 22:17:47.196'),(3,'smoke1794665898@webox.com','$2a$10$ctFfXBWKzxYICtfac.VSR.Wxhp1GELk/d.hl6PQZDZ8FsE35hb5hG','Smoke Tester','EMPLOYEE','ACTIVE','HQ','2026-11-14 22:18:19.068','2026-11-14 22:18:19.068'),(4,'smoke1794665935@webox.com','$2a$10$OuBsl4Z0FjYt7U3VbiVZOOdLuaks0zEyF29XbvVxNTQkGImv0..9a','Smoke Tester','EMPLOYEE','ACTIVE','HQ','2026-11-14 22:18:55.466','2026-11-14 22:18:55.466'),(5,'smoke1794666006@webox.com','$2a$10$yba91ERY/6SU/1I1rq0soemvZU2kA..qC4Xi5W33jQfwfLVXU1s9G','Smoke Tester','EMPLOYEE','ACTIVE','HQ','2026-11-14 22:20:06.431','2026-11-14 22:20:06.431'),(6,'smoke1794666044@webox.com','$2a$10$Mk14b1pMieRlfYInrO4.UOMSyE4adG8MijxOMOlNpc2di8Wr2Rv8q','Smoke Tester','EMPLOYEE','ACTIVE','HQ','2026-11-14 22:20:44.177','2026-11-14 22:20:44.177'),(7,'race_pa50_0@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(8,'race_pa50_1@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(9,'race_pa50_2@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(10,'race_pa50_3@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(11,'race_pa50_4@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(12,'race_pa50_5@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(13,'race_pa50_6@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(14,'race_pa50_7@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(15,'race_pa50_8@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(16,'race_pa50_9@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(17,'race_pa50_10@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(18,'race_pa50_11@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(19,'race_pa50_12@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(20,'race_pa50_13@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(21,'race_pa50_14@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(22,'race_pa50_15@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(23,'race_pa50_16@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(24,'race_pa50_17@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(25,'race_pa50_18@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(26,'race_pa50_19@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(27,'race_pa50_20@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(28,'race_pa50_21@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(29,'race_pa50_22@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(30,'race_pa50_23@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(31,'race_pa50_24@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(32,'race_pa50_25@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(33,'race_pa50_26@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(34,'race_pa50_27@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(35,'race_pa50_28@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(36,'race_pa50_29@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(37,'race_pa50_30@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(38,'race_pa50_31@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(39,'race_pa50_32@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(40,'race_pa50_33@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(41,'race_pa50_34@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(42,'race_pa50_35@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(43,'race_pa50_36@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(44,'race_pa50_37@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(45,'race_pa50_38@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(46,'race_pa50_39@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(47,'race_pa50_40@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(48,'race_pa50_41@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(49,'race_pa50_42@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(50,'race_pa50_43@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(51,'race_pa50_44@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(52,'race_pa50_45@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(53,'race_pa50_46@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(54,'race_pa50_47@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(55,'race_pa50_48@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(56,'race_pa50_49@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:39:51.690','2026-11-14 22:39:51.690'),(57,'race_dbg_0@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:02.365','2026-11-14 22:40:02.365'),(58,'race_dbg_1@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:05.661','2026-11-14 22:40:05.661'),(59,'race_pa50x_0@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(60,'race_pa50x_1@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(61,'race_pa50x_2@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(62,'race_pa50x_3@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(63,'race_pa50x_4@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(64,'race_pa50x_5@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(65,'race_pa50x_6@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(66,'race_pa50x_7@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(67,'race_pa50x_8@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(68,'race_pa50x_9@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(69,'race_pa50x_10@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(70,'race_pa50x_11@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(71,'race_pa50x_12@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(72,'race_pa50x_13@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(73,'race_pa50x_14@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(74,'race_pa50x_15@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(75,'race_pa50x_16@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(76,'race_pa50x_17@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(77,'race_pa50x_18@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(78,'race_pa50x_19@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(79,'race_pa50x_20@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(80,'race_pa50x_21@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(81,'race_pa50x_22@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(82,'race_pa50x_23@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(83,'race_pa50x_24@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(84,'race_pa50x_25@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(85,'race_pa50x_26@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(86,'race_pa50x_27@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(87,'race_pa50x_28@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(88,'race_pa50x_29@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(89,'race_pa50x_30@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(90,'race_pa50x_31@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(91,'race_pa50x_32@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(92,'race_pa50x_33@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(93,'race_pa50x_34@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(94,'race_pa50x_35@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(95,'race_pa50x_36@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(96,'race_pa50x_37@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(97,'race_pa50x_38@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(98,'race_pa50x_39@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(99,'race_pa50x_40@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(100,'race_pa50x_41@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(101,'race_pa50x_42@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(102,'race_pa50x_43@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(103,'race_pa50x_44@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(104,'race_pa50x_45@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(105,'race_pa50x_46@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(106,'race_pa50x_47@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(107,'race_pa50x_48@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(108,'race_pa50x_49@test.com','$2b$10$SfE7IXQu7pCsHignSZhfAuKfYB/YaQLlgvqS1jdNtDI4FDrKZzFBq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:40:10.031','2026-11-14 22:40:10.031'),(109,'refreshfix1794667283@test.com','$2a$10$OE9S6SFNadQaZmXk5fxhBO/3/xSvk1A9yi5S.ySuBVFIOwmszyjva','RefreshFix','EMPLOYEE','ACTIVE','HQ','2026-11-14 22:41:24.018','2026-11-14 22:41:24.018'),(110,'pa_1794667287_a@test.com','$2a$10$D0XupVy19jQX9PoSPcLNseXXbwd2/Y9DUQo8iFyU3/jYKaH5yf9KS',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:41:27.710','2026-11-14 22:41:27.710'),(111,'pa_1794667287_r@test.com','$2a$10$9Rub63dxrsozbvZSyyicq.zOHapeNSGagOtZ4iko88s89XQzCbdhq',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:41:27.929','2026-11-14 22:41:27.929'),(112,'pa2_1794667308@test.com','$2a$10$CXpPBCvyJQVS6xJ4rgtdY.P/aV7wawOZAj9MQce/tAdLpOGO2yLhe',NULL,'EMPLOYEE','ACTIVE','HQ','2026-11-14 22:41:48.609','2026-11-14 22:41:48.609'),(113,'fr.review.224153@webox.com','$2a$10$Qkr6gdtP/q3o2SZszGir9OMSxm1QxsWro419xW6q4oWZAW5s7eiwu','FR Review','EMPLOYEE','ACTIVE','HQ','2026-11-14 22:41:53.852','2026-11-14 22:41:53.852'),(114,'refreshfix1794667317@test.com','$2a$10$UmBIWacRY82nVOnXPDtRuu3ngT4AdLnSfkfy1SOqXjKqAT29Fask2','RefreshFix','EMPLOYEE','ACTIVE','HQ','2026-11-14 22:41:57.399','2026-11-14 22:41:57.399');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'req_6343a752e110'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-14 22:52:29
